export const BASE_URL = "http://127.0.0.1:8000/api/";
export const PAGE_SIZE = 10;
export const TIMEOUT = 10000;
export const CONTENT_TYPE = "application/json";